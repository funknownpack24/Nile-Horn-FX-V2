@rem Gradle wrapper bootstrap script for Windows
@echo off
gradle %*
