# Preserve JavaScript bridge methods for WebView + AdMob
-keepclassmembers class com.nilehorn.fx.MainActivity$AdMobWebBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface

# Preserve Google Mobile Ads SDK classes
-keep public class com.google.android.gms.ads.** {
    public *;
}
-dontwarn com.google.android.gms.ads.**
