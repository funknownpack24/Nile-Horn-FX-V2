package com.nilehorn.fx

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    companion object {
        private const val BANNER_AD_UNIT_ID = "ca-app-pub-1576105176117641/7459894363"
    }

    private lateinit var rootContainer: LinearLayout
    private lateinit var webView: WebView
    private lateinit var adBannerContainer: FrameLayout
    private var adView: AdView? = null
    private var isAdMobInitialized = false
    private var isBannerLoaded = false

    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rootContainer = findViewById(R.id.rootContainer)
        webView = findViewById(R.id.webView)
        adBannerContainer = findViewById(R.id.adBannerContainer)

        setupWindowInsets()
        setupOfflineFirstWebView()
        setupBackNavigation()
        registerConnectivityObserver()

        MobileAds.initialize(this) {
            isAdMobInitialized = true
            if (isNetworkAvailable()) {
                loadAdaptiveBannerAd()
            }
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(rootContainer) { view, windowInsets ->
            val insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(insets.left, insets.top, insets.right, insets.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupOfflineFirstWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportZoom(false)
        }

        webView.addJavascriptInterface(AdMobWebBridge(), "AndroidAdMob")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false
                return !(url.startsWith("file:///android_asset/") ||
                    url.startsWith("blob:") ||
                    url.startsWith("data:"))
            }
        }

        webView.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            handleWebViewDownload(url, contentDisposition, mimeType)
        })

        webView.loadUrl("file:///android_asset/nilehorn-fx.html")
    }

    private fun handleWebViewDownload(url: String, contentDisposition: String?, mimeType: String?) {
        try {
            if (url.startsWith("data:")) {
                val commaIndex = url.indexOf(',')
                if (commaIndex == -1) return
                val header = url.substring(5, commaIndex)
                val dataPart = url.substring(commaIndex + 1)
                val resolvedMime = header.substringBefore(';').ifBlank { mimeType ?: "application/octet-stream" }
                val ext = when {
                    resolvedMime.contains("png") -> "png"
                    resolvedMime.contains("jpeg") || resolvedMime.contains("jpg") -> "jpg"
                    resolvedMime.contains("json") -> "json"
                    else -> "bin"
                }
                val fileName = URLUtil.guessFileName(url, contentDisposition, resolvedMime)
                    .let { if (it.endsWith(".bin")) "NileHornFX_${System.currentTimeMillis()}.$ext" else it }
                val bytes = if (header.contains(";base64")) {
                    Base64.decode(dataPart, Base64.DEFAULT)
                } else {
                    java.net.URLDecoder.decode(dataPart, "UTF-8").toByteArray(Charsets.UTF_8)
                }
                saveBytesToDownloads(fileName, resolvedMime, bytes)
            } else if (url.startsWith("blob:")) {
                val js = "(function(){fetch('" + url + "').then(function(r){return r.blob();}).then(function(b){var rd=new FileReader();rd.onloadend=function(){if(window.AndroidAdMob&&window.AndroidAdMob.saveBase64File){window.AndroidAdMob.saveBase64File(rd.result,b.type||'application/octet-stream');}};rd.readAsDataURL(b);});})();"
                webView.evaluateJavascript(js, null)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveBytesToDownloads(fileName: String, mimeType: String, bytes: ByteArray) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, mimeType)
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
            resolver.openOutputStream(uri)?.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        } else {
            @Suppress("DEPRECATION")
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val outFile = File(downloadsDir, fileName)
            FileOutputStream(outFile).use { it.write(bytes) }
        }
        Toast.makeText(this, "Saved to Downloads: $fileName", Toast.LENGTH_SHORT).show()
    }

    private fun loadAdaptiveBannerAd() {
        if (!isAdMobInitialized || !isNetworkAvailable()) return

        if (adView == null) {
            val banner = AdView(this).apply {
                adUnitId = BANNER_AD_UNIT_ID
                setAdSize(calculateAnchoredAdaptiveAdSize())
                adListener = object : AdListener() {
                    override fun onAdLoaded() {
                        isBannerLoaded = true
                        adBannerContainer.visibility = View.VISIBLE
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        isBannerLoaded = false
                        adBannerContainer.visibility = View.GONE
                    }
                }
            }
            adBannerContainer.removeAllViews()
            adBannerContainer.addView(banner)
            adView = banner
        }

        adView?.loadAd(AdRequest.Builder().build())
    }

    private fun calculateAnchoredAdaptiveAdSize(): AdSize {
        val displayMetrics = resources.displayMetrics
        val adWidthPixels = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            windowManager.currentWindowMetrics.bounds.width().toFloat()
        } else {
            displayMetrics.widthPixels.toFloat()
        }
        val adWidthDp = (adWidthPixels / displayMetrics.density).toInt().coerceAtLeast(320)
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidthDp)
    }

    private fun registerConnectivityObserver() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread {
                    if (!isBannerLoaded) {
                        loadAdaptiveBannerAd()
                    }
                }
            }

            override fun onLost(network: Network) {
                runOnUiThread {
                    if (!isNetworkAvailable() && !isBannerLoaded) {
                        adBannerContainer.visibility = View.GONE
                    }
                }
            }
        }
        networkCallback = callback
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager.registerNetworkCallback(request, callback)
    }

    private fun isNetworkAvailable(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    inner class AdMobWebBridge {
        @JavascriptInterface
        fun onNetworkChanged(isOnline: Boolean) {
            runOnUiThread {
                if (isOnline && !isBannerLoaded) {
                    loadAdaptiveBannerAd()
                }
            }
        }

        @JavascriptInterface
        fun saveBase64File(dataUrl: String, mimeType: String) {
            runOnUiThread {
                handleWebViewDownload(dataUrl, null, mimeType)
            }
        }
    }

    override fun onPause() {
        adView?.pause()
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        adView?.resume()
    }

    override fun onDestroy() {
        networkCallback?.let { connectivityManager.unregisterNetworkCallback(it) }
        adView?.destroy()
        webView.destroy()
        super.onDestroy()
    }
}
