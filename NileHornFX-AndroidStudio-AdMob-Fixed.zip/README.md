# NileHorn FX — Offline-First Currency Exchange & Customer Ledger Android App

Complete Android Studio WebView project with native Google AdMob integration, offline receipt/backup downloads, and automated GitHub Actions APK builds.

## AdMob Configuration
- **Application ID**: `ca-app-pub-1576105176117641~6711461467` (`app/src/main/AndroidManifest.xml`)
- **Banner Ad Unit ID**: `ca-app-pub-1576105176117641/7459894363` (`MainActivity.kt`)

## How to Build the APK on GitHub Actions
1. Extract `NileHornFX-AndroidStudio-AdMob-Fixed.zip`.
2. Upload **all extracted files and folders** (including the hidden `.github` folder) directly to the root of your GitHub repository.
3. Open the **Actions** tab in GitHub — the workflow automatically compiles both **NileHornFX-Debug-APK** and **NileHornFX-Release-APK** under **Artifacts**.
